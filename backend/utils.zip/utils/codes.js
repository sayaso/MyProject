const SUCCESS_CODE = 200;
const CREATE_CODE = 201;

module.exports = {
  SUCCESS_CODE,
  CREATE_CODE,
};
